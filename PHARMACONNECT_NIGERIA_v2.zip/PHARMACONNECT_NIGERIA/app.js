const courses = [
 {id:"vitamins",icon:"🧪",title:"Vitamins",level:"Core topic",description:"Classification, sources, functions, and common deficiency conditions.",notes:"Vitamins are organic micronutrients required in small amounts for normal growth and body function. They are commonly classified as fat-soluble (A, D, E, K) and water-soluble (B-complex and C). Sources include varied foods such as vegetables, fruits, grains, eggs, dairy foods, fish, and legumes. Deficiency effects vary by vitamin; examples include night blindness with vitamin A deficiency, rickets in children with vitamin D deficiency, and scurvy with vitamin C deficiency. Use approved course texts for detailed diagnosis and treatment."},
 {id:"powders",icon:"⚗️",title:"Pharmaceutical Powders",level:"Dosage forms",description:"Definition, types, uses, and basic preparation principles.",notes:"Pharmaceutical powders are dry, finely divided preparations containing one or more substances. They may be intended for internal or external use and can be supplied as divided doses or bulk powders. Important quality considerations include particle size, mixing uniformity, moisture protection, packaging, labeling, and dose accuracy. Preparation and dispensing must follow the institution's procedures and applicable standards."},
 {id:"compounding",icon:"🧴",title:"Pharmaceutical Compounding",level:"Practical skills",description:"Key terms, dosage calculations awareness, equipment, and safety.",notes:"Compounding is the preparation, mixing, assembling, or altering of a medicine to meet an appropriate patient need under applicable professional and legal standards. Core principles include checking the formula, confirming ingredient identity and calculations, using suitable equipment, preventing contamination, labeling correctly, documenting the process, and observing beyond-use dates and storage requirements. Students should practise only under qualified supervision."},
 {id:"pharmacology",icon:"📚",title:"Introduction to Pharmacology",level:"Foundations",description:"Learn what pharmacology studies and its major branches.",notes:"Pharmacology is the study of drugs and their interactions with living systems. Major areas include pharmacodynamics (what a drug does to the body), pharmacokinetics (how the body absorbs, distributes, metabolizes, and eliminates a drug), toxicology, and clinical pharmacology. Medicine selection and use require qualified professional judgment and reliable references."},
 {id:"rational-use",icon:"✓",title:"Rational Use of Medicines",level:"Patient safety",description:"Appropriate medicine use, adherence, and safe dispensing concepts.",notes:"Rational use of medicines means patients receive medicines appropriate to their clinical needs, in doses that meet their individual requirements, for an adequate period, and at the lowest reasonable cost to them and the community. Pharmacy personnel contribute through accurate dispensing, clear counseling within their scope, checking for potential problems, protecting confidentiality, and referring questions beyond their competence."},
 {id:"ict-pharmacy",icon:"💻",title:"ICT in Pharmacy",level:"Digital health",description:"Digital records, stock systems, privacy, and technology in practice.",notes:"Information and communication technology can support inventory management, electronic records, prescription workflows, expiry tracking, and communication between healthcare teams. Systems should protect personal information, use appropriate access controls, maintain backups, and be checked for data accuracy. Digital tools support—but do not replace—professional review."}
];
const questions = [
 {q:"Which group contains only fat-soluble vitamins?",a:["B-complex and C","A, D, E and K","B1, B6 and B12","C and K"],correct:1,why:"Vitamins A, D, E and K are fat-soluble."},
 {q:"Pharmacodynamics mainly studies…",a:["How the body eliminates a drug","How drugs affect the body","Medicine packaging only","How medicines are advertised"],correct:1,why:"Pharmacodynamics describes the effects of drugs and their mechanisms of action."},
 {q:"Which is an important consideration when dispensing a powder?",a:["Ignoring the label","Dose accuracy and suitable packaging","Mixing without checking ingredients","Using any container available"],correct:1,why:"Dose accuracy, ingredient checks, packaging and labeling are important quality considerations."},
 {q:"What is a key purpose of expiry-date monitoring in a pharmacy?",a:["To improve shelf appearance","To identify products that must not be supplied after expiry","To avoid stock records","To replace temperature monitoring"],correct:1,why:"Expiry-date monitoring helps prevent expired products from being supplied."},
 {q:"Which statement best describes rational use of medicines?",a:["Every illness needs an antibiotic","Use medicines appropriate to the patient's needs and requirements","Take a larger dose for faster results","Share medicines with family"],correct:1,why:"Rational use involves appropriate medicine choice, dose, duration and cost."},
 {q:"Which is an example of ICT use in pharmacy?",a:["Electronic inventory and expiry tracking","Removing all records","Sharing patient details publicly","Skipping stock checks"],correct:0,why:"Digital inventory systems can support stock control and expiry tracking."}
];
const grid=document.querySelector("#courseGrid"), searchInput=document.querySelector("#searchInput");
let qIndex=0, score=0, answered=false;
function renderCourses(query=""){
 const filtered=courses.filter(c=>(c.title+" "+c.description+" "+c.notes).toLowerCase().includes(query.toLowerCase()));
 grid.innerHTML=filtered.map(c=>`<article class="course-card"><div class="course-icon">${c.icon}</div><h3>${c.title}</h3><p>${c.description}</p><button class="text-button" data-course="${c.id}">Read notes →</button></article>`).join("");
 document.querySelector("#noResults").classList.toggle("hidden",filtered.length!==0);
}
function showNotes(id){
 const c=courses.find(x=>x.id===id); if(!c)return;
 const dialog=document.createElement("dialog");dialog.className="notes-dialog";
 dialog.innerHTML=`<form method="dialog"><button class="close-dialog" aria-label="Close notes">✕</button></form><p class="eyebrow">STUDY NOTES</p><h2>${c.icon} ${c.title}</h2><p>${c.notes}</p><p class="note-warning">Use your lecturer's notes and approved references for examination preparation.</p><form method="dialog"><button class="button button-primary">Done reading</button></form>`;
 document.body.appendChild(dialog);dialog.showModal();dialog.addEventListener("close",()=>dialog.remove());
}
function renderQuestion(){
 const item=questions[qIndex];answered=false;
 document.querySelector("#questionCounter").textContent=`Question ${qIndex+1} of ${questions.length}`;
 document.querySelector("#scoreCounter").textContent=`Score: ${score}`;
 document.querySelector("#questionText").textContent=item.q;
 document.querySelector("#feedback").textContent="";
 document.querySelector("#nextBtn").disabled=true;
 document.querySelector("#nextBtn").textContent=qIndex===questions.length-1?"See result →":"Next question →";
 document.querySelector("#answers").innerHTML=item.a.map((a,i)=>`<button class="answer" data-answer="${i}">${String.fromCharCode(65+i)}. ${a}</button>`).join("");
}
function chooseAnswer(i,button){
 if(answered)return;answered=true;const item=questions[qIndex];const buttons=[...document.querySelectorAll(".answer")];
 buttons.forEach((b,n)=>{b.disabled=true;if(n===item.correct)b.classList.add("correct")});
 if(i===item.correct){score++;button.classList.add("correct");document.querySelector("#feedback").textContent="Correct! "+item.why}
 else{button.classList.add("incorrect");document.querySelector("#feedback").textContent="Not quite. "+item.why}
 document.querySelector("#scoreCounter").textContent=`Score: ${score}`;document.querySelector("#nextBtn").disabled=false;
}
grid.addEventListener("click",e=>{const b=e.target.closest("[data-course]");if(b)showNotes(b.dataset.course)});
searchInput.addEventListener("input",e=>renderCourses(e.target.value));
document.querySelector("#answers").addEventListener("click",e=>{const b=e.target.closest("[data-answer]");if(b)chooseAnswer(Number(b.dataset.answer),b)});
document.querySelector("#nextBtn").addEventListener("click",()=>{if(!answered)return;if(qIndex<questions.length-1){qIndex++;renderQuestion()}else{document.querySelector("#questionText").textContent=`Quiz complete — you scored ${score} out of ${questions.length}.`;document.querySelector("#answers").innerHTML="";document.querySelector("#feedback").textContent=score===questions.length?"Excellent work! Review the notes to keep learning.":"Good effort. Review the course notes and try again.";document.querySelector("#nextBtn").disabled=true;document.querySelector("#questionCounter").textContent="Completed"}});
document.querySelector("#restartBtn").addEventListener("click",()=>{qIndex=0;score=0;renderQuestion()});
document.querySelector("#courseCount").textContent=courses.length;document.querySelector("#quizCount").textContent=questions.length;renderCourses();renderQuestion();
let deferredPrompt;
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredPrompt=e;const btn=document.querySelector("#installBtn");btn.classList.remove("hidden");btn.addEventListener("click",async()=>{if(!deferredPrompt)return;deferredPrompt.prompt();await deferredPrompt.userChoice;deferredPrompt=null;btn.classList.add("hidden")},{once:true})});
if("serviceWorker" in navigator && location.protocol.startsWith("http"))window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(err=>console.info("Offline support unavailable:",err)));
