# PHARMACONNECT NIGERIA

**Founder:** Yakubu Aliyu Adamu  
**Project:** Responsive pharmacy-learning website and installable Progressive Web App (PWA).

## Current features
- Responsive mobile/desktop interface
- Pharmacy topic cards and searchable notes
- Short multiple-choice quiz with score and feedback
- PWA manifest and install prompt where supported
- Basic service-worker caching for offline use after a successful online load

## Files
- `index.html` — main page
- `styles.css` — responsive design
- `app.js` — course notes, search, quiz, and install prompt
- `manifest.json` — PWA metadata
- `icon.svg` — app icon
- `sw.js` — service worker and caching

## Run locally
Open `index.html` for a basic preview. Some PWA features require HTTPS or localhost and may not work from a `file://` URL.

## Publish with GitHub Pages
1. Create a GitHub repository named `pharmaconnect-nigeria`.
2. Upload the contents of this folder to the repository root (not just a ZIP file).
3. Open **Settings → Pages**.
4. Select deployment from the `main` branch and `/(root)`, then save.
5. Open the HTTPS URL GitHub provides.

## Install on Android
Open the published HTTPS website in Chrome. Use the browser menu and select **Install app** or **Add to Home screen**, if offered.

## Important limitations
This is a front-end starter, not a native Android APK. It does not include real user accounts, cloud database, secure admin dashboard, payments, ads, analytics, or Google Play publishing. The current notes and quiz are starter educational content and should be reviewed by qualified pharmacy educators. Do not use the app to provide patient-specific treatment advice. Before public release, add appropriate privacy/security review, accessibility checks, verified content, and a secure backend if collecting user data.
